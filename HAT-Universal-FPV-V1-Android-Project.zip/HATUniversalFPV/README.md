# H.A.T. Universal FPV — V1

Android prototype focused on FPV camera viewing, automatic discovery, snapshots, and raw MJPEG stream capture. No flight controls.

## Important
This build does not claim compatibility with every RC camera protocol. It probes common HTTP/MJPEG endpoints and accepts a manual HTTP stream URL. Proprietary camera protocols may require a model-specific adapter.

The Record button saves the incoming MJPEG stream as `.mjpeg` in the app's external files area; it is not yet a native MP4 encoder.

## Build
Open in Android Studio with Android Gradle Plugin 8.5.2 / SDK 35, then Build > Build APK(s).
