package com.hat.universalfpv;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    WebView web; TextView status, log, empty; Button record; ExecutorService pool=Executors.newFixedThreadPool(8);
    volatile boolean recording=false; volatile InputStream recIn; volatile OutputStream recOut;
    final String[] hosts={"192.168.4.1","192.168.1.1","192.168.0.1","192.168.10.1","192.168.8.1","192.168.1.100"};
    final String[] paths={"/","/video","/video_feed","/mjpeg","/stream","/live","/live.mjpg","/video.mjpg","/?action=stream"};
    final int[] ports={80,8080,8000,5000};
    @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(com.hat.universalfpv.R.layout.activity_main);
        status=findViewById(R.id.status); log=findViewById(R.id.log); empty=findViewById(R.id.empty); web=findViewById(R.id.web); record=findViewById(R.id.record);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient(){public void onPageFinished(WebView v,String u){empty.setVisibility(View.GONE); status.setText("FPV connected"); log.setText(u);}});
        findViewById(R.id.auto).setOnClickListener(v->autoDetect());
        findViewById(R.id.manual).setOnClickListener(v->manual());
        findViewById(R.id.photo).setOnClickListener(v->photo());
        record.setOnClickListener(v->{ if(!recording) startRawRecord(); else stopRecord(); });
        requestPermissionsIfNeeded();
    }
    void requestPermissionsIfNeeded(){ if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.READ_MEDIA_IMAGES},20); else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.READ_EXTERNAL_STORAGE},20); }
    void manual(){ final EditText e=new EditText(this); e.setHint("http://192.168.4.1/video"); e.setSingleLine(); new AlertDialog.Builder(this).setTitle("FPV stream URL").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Connect",(d,w)->connect(e.getText().toString().trim())).show(); }
    void autoDetect(){ status.setText("Scanning…"); log.setText("Trying common Wi‑Fi FPV camera endpoints"); empty.setVisibility(View.VISIBLE);
        for(String h:hosts) for(int p:ports) for(String path:paths){String u="http://"+h+":"+p+path; pool.submit(()->probe(u));}
    }
    void probe(String u){try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(700); c.setReadTimeout(700); c.setRequestMethod("GET"); c.setInstanceFollowRedirects(true); c.connect(); int code=c.getResponseCode(); String ct=c.getContentType(); if(code>=200&&code<400&&(ct==null||ct.toLowerCase().contains("mjpeg")||ct.toLowerCase().contains("multipart")||ct.toLowerCase().contains("image")||ct.toLowerCase().contains("html")||ct.toLowerCase().contains("video"))){runOnUiThread(()->{if(status.getText().toString().startsWith("Scanning")){connect(u); log.setText("Detected: "+u);}}); c.disconnect();}}catch(Exception ignored){}}
    void connect(String u){ if(u==null||u.isEmpty())return; try{new URL(u); }catch(Exception e){Toast.makeText(this,"Invalid URL",Toast.LENGTH_SHORT).show();return;} status.setText("Connecting…"); empty.setVisibility(View.GONE); web.loadUrl(u); }
    void photo(){ web.post(()->{web.measure(View.MeasureSpec.makeMeasureSpec(web.getWidth(),View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(web.getHeight(),View.MeasureSpec.EXACTLY)); web.layout(0,0,web.getWidth(),web.getHeight()); Bitmap b=Bitmap.createBitmap(web.getWidth(),web.getHeight(),Bitmap.Config.ARGB_8888); Canvas c=new Canvas(b); web.draw(c); savePhoto(b);}); }
    void savePhoto(Bitmap b){String n="HAT_FPV_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg"; ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,n);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/HAT Universal FPV");try{Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);OutputStream o=getContentResolver().openOutputStream(u);b.compress(Bitmap.CompressFormat.JPEG,92,o);o.close();Toast.makeText(this,"Photo saved",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Photo save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    void startRawRecord(){String u=web.getUrl();if(u==null||!u.startsWith("http")){Toast.makeText(this,"Connect to an FPV stream first",Toast.LENGTH_SHORT).show();return;} record.setText("■ STOP");recording=true; status.setText("Recording stream…"); pool.submit(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(3000);c.setReadTimeout(0);c.connect();recIn=c.getInputStream();String n="HAT_FPV_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mjpeg";File f=new File(getExternalFilesDir(null),n);recOut=new FileOutputStream(f);byte[] buf=new byte[16384];int k;while(recording&&(k=recIn.read(buf))!=-1)recOut.write(buf,0,k);recOut.close();recIn.close();runOnUiThread(()->{status.setText("Saved MJPEG recording");Toast.makeText(this,"Recording saved: "+f.getName(),Toast.LENGTH_LONG).show();});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Record failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}finally{recording=false;}});}
    void stopRecord(){recording=false;try{if(recIn!=null)recIn.close();}catch(Exception ignored){}try{if(recOut!=null)recOut.close();}catch(Exception ignored){}record.setText("● RECORD");status.setText("FPV connected");}
    @Override protected void onDestroy(){stopRecord();pool.shutdownNow();super.onDestroy();}
}
